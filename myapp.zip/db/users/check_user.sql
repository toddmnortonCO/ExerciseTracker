select * from exercise_tracker_users
where email = ${email};