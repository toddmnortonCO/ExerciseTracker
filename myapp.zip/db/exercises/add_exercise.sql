insert into exercises (
    user_id,
    activity,
    duration,
    distance,
    summary
) values (
    $1,
    $2,
    $3,
    $4,
    $5
)