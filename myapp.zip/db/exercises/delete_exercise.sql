delete from exercises
where exercise_id = $1;