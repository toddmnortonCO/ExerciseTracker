update exercises
set summary = ${summary}
where exercise_id = ${exercise_id};