delete from exercise_comments
where comment_id = $1;