insert into exercise_comments (
    comment_id,
    comments
) values (
    $1,
    $2
)