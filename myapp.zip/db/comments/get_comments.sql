select * from exercise_comments ec
where comments_user_id = $1;